#include <iostream>
#include"OsHeader.h"

int main()
{

    OperatingSystem os;
    os.run();

    return 0;
}