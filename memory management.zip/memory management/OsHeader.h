#pragma once
#include<string>
#include <list> 
using namespace std;

struct Process {
    string name = "";
    int size = 0, startingAddress = 0, endingAddress = 0;
};

struct VoidSpace {
    int startSpace, endSpace;
};

class OperatingSystem {

private:                                  //PRIVATE DATA MEMBERS 

    list <Process> processes;
    list <VoidSpace> voidSpaces;
    int totalSize = 5000, mainStartAddress = 0;
    int  remainingSize = totalSize, pointer = mainStartAddress;

                                         //PRIVATE MEMBER FUNCTIONS

    void setProcessAddress(Process& process); // this method will assign addressses to the process

    void setProcessAddress(list<Process>::iterator& process); // overloaded method

    void adjustProcessBetween(Process process);  // set the process to the appropriate location

    bool ifGoodSpaceBetween(Process& process); // check if enough space segment is available 

    void display(); //display all the running processes 

    bool setVoidSpace(list<Process>::iterator& it); // when process leaves this method releases the memory

public:                                  //PUBLIC MEMBER FUNCTIONS

    void loadProcess(); //this method load the processes

    void unLoadProcess(); //this method unload the processes

    void desegmentation(); // this method arrange the processes and merge all the segment void spaces to make one large space 

    void run(); // this method run the whole system so that you need not to worry how internal system working
};
