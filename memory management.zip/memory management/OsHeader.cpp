#include<iostream>
#include "OsHeader.h"
using namespace std;

                //PRIVATE DATA MEMBERS AND MEMBER FUNCTIONS


    void OperatingSystem::setProcessAddress(Process& process) {
        process.startingAddress = pointer;
        process.endingAddress = (process.startingAddress + process.size) - 1;
        pointer = process.endingAddress + 1;
        remainingSize = remainingSize - process.size;
        processes.push_back(process);
    }

    void OperatingSystem::setProcessAddress(list<Process>::iterator& process) { //method overloading
        process->startingAddress = pointer;
        process->endingAddress = (process->startingAddress + process->size) - 1;
        pointer = process->endingAddress + 1;

    }

    void OperatingSystem::adjustProcessBetween(Process process) {
        for (list<Process>::iterator it = processes.begin(); it != processes.end(); it++) {
            if (it->startingAddress > process.endingAddress) {
                processes.insert(it, process);
                return;
            }
        }
    }

    bool OperatingSystem::ifGoodSpaceBetween(Process& process) {
        for (list<VoidSpace>::iterator it = voidSpaces.begin(); it != voidSpaces.end(); it++) {
            if ((it->endSpace - it->startSpace) >= process.size - 1) {

                if ((it->endSpace - it->startSpace) == process.size) {
                    process.startingAddress = it->startSpace;
                    process.endingAddress = it->endSpace;
                    voidSpaces.erase(it);
                    // pointerVoid = it->startSpace; //set void pointer to next void space

                }
                else {
                    process.startingAddress = it->startSpace;
                    process.endingAddress = (it->startSpace + process.size) - 1;
                    it->startSpace = process.endingAddress + 1;
                    // pointerVoid = it->startSpace;

                }
                // processes.push_back(process);
                remainingSize = remainingSize - process.size;
                adjustProcessBetween(process);
                return true;
            }
        }
        return false;
    }

    void OperatingSystem::display() {
        cout << "\nprocess\tSize\tStarting address\tEnding address\n";
        for (list<Process>::iterator it = processes.begin(); it != processes.end(); ++it) {
            cout << it->name << "\t" << it->size << "\t" << it->startingAddress << "\t\t\t" << it->endingAddress << endl;
        }
        cout << endl << "Remaining Size " << remainingSize << endl;
    }

    bool OperatingSystem::setVoidSpace(list<Process>::iterator& it) {

        if (next(it) != processes.end()) {
            VoidSpace voidSpace;
            voidSpace.startSpace = it->startingAddress;
            voidSpace.endSpace = it->endingAddress;
            voidSpaces.push_back(voidSpace);
            return true;
        }
        return false;
    }

                              //PUBLIC MEMBER FUNCTIONS

    void OperatingSystem::loadProcess() {
        Process process;
        int temp;
        cout << "Enter process name\n";
        cin >> process.name;
        cout << "Enter process size\n";
        cin >> process.size;


        if (remainingSize - process.size >= 0) { // If enough space 

            if (totalSize >= pointer + process.size) {

                setProcessAddress(process); //set process address , pointer , remainingSize and add in list
                cout << "Process " << process.name << " added in the end\n";

            }
            else if (ifGoodSpaceBetween(process)) {
                cout << "Process " << process.name << " added in some void segment in between\n";
            }
            //setProcessAddress(process); //set process address
            //remainingSize = remainingSize - process.size;
            //processes.push_back(process);
        }
        else {
            cout << "Not enough space\n";

        }
    }

    void OperatingSystem::unLoadProcess() {

        string temp;
        bool notFound = true;
        cout << "Enter process name\n";
        cin >> temp;
        for (list<Process>::iterator it = processes.begin(); it != processes.end(); it++) {
            if (it->name == temp) {
                cout << "Process " << it->name << " removed \n";

                if (setVoidSpace(it)) {//set the void spaces if in between
                    cout << "Created void space\n";
                    remainingSize = remainingSize + it->size;
                    processes.erase(it);
                    return;
                }

                pointer = it->startingAddress;
                remainingSize = remainingSize + it->size;
                processes.erase(it);
                notFound = false;
                break; //remove this if you want to rease all the processes of that specific name
            }
        }
        if (notFound) cout << "No such process exist\n";

    }

    void OperatingSystem::desegmentation() {
        mainStartAddress = 0;
        pointer = mainStartAddress;

        for (list<Process>::iterator it = processes.begin(); it != processes.end(); it++) {
            setProcessAddress(it);
        }
        voidSpaces.clear();

    }

    void OperatingSystem::run() {
        char option;

        while (true) {

            cout << "Choose an option\n";
            cout << " a: Load process\n";
            cout << " b: Unload process\n";
            cout << " c: Desegmentation\n";
            cout << " d: Exit\n";

            cin >> option;
            if (option == 'd') break;

            switch (option) {
            case 'a': loadProcess();display();break;
            case 'b': unLoadProcess();display();break;
            case 'c': desegmentation();display();break;
            default: cout << "Choose correct option\n";break;
            }
        }
    }

